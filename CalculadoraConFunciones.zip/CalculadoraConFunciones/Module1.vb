﻿Module Module1
    Public Function FunSumar(num1 As Integer, num2 As Integer)
        Dim resultado As Integer
        resultado = num1 + num2
        Return resultado

    End Function
    Public Function FunRestar(num1 As Integer, num2 As Integer)
        Dim resultado As Integer
        resultado = num1 - num2
        Return resultado
    End Function
    Public Function FunDividir(num1 As Integer, num2 As Integer)
        Dim resultado As Integer
        resultado = num1 / num2
        Return resultado
    End Function
    Public Function FunMultiplicar(num1 As Integer, num2 As Integer)
        Dim resultado As Integer
        resultado = num1 * num2
        Return resultado
    End Function

End Module
