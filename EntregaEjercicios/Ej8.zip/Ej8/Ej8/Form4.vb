﻿Public Class FormEducacion
    Private Sub FormEducacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Asignar texto a un RichTextBox
        txt_Educacion.Text = "En nuestros primeros dos años de educación, los niños aprenden haciendo." & vbCrLf & " A través de experiencias prácticas y actividades lúdicas, los pequeños desarrollan habilidades cognitivas, sociales y emocionales."

    End Sub
End Class