﻿Public Class FormProductos
    Private Sub FormProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Asignar texto a un RichTextBox
        txt_Productos.Text = "¡Ropa cómoda y divertida para que los niños se sientan libres y seguros en cada movimiento!" & vbCrLf & " Fabricada con materiales suaves y duraderos."

    End Sub

End Class
