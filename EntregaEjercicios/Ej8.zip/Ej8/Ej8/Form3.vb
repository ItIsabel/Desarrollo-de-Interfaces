﻿Imports System.Windows.Controls

Public Class FormLactancia
    Private Sub FormLactancia_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Asignar texto a un RichTextBox
        txt_Lactacia.Text = "La lactancia es un viaje maravilloso lleno de amor, conexión y aprendizaje." & vbCrLf & " Es mucho más que alimentar, es nutrir cuerpo y alma."

    End Sub
End Class