﻿Public Class FormDesarrolo
    Private Sub FormDesarrolo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txt_Desarrollo.Text = "Durante los primeros dos años, los bebés experimentan un crecimiento físico impresionante. Sus cuerpos se alargan, ganan peso y desarrollan habilidades motoras como gatear, sentarse y caminar."
    End Sub
End Class